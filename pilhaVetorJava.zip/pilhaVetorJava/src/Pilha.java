public class Pilha {
    private int valores[];
    private int topo;

    
    public Pilha(){
        valores = new int[10];
        topo = -1; //indicar que a pilha esta vazia, posicao do topo e -1
    }

    public void empilha(int elemento){
        topo = topo+1;
        valores[topo]=elemento;
    }

    public boolean vazio(){
        return (topo == -1);
    }

    public boolean cheio(){
        return (topo==9);
    }

    public int desempilha(){
        int elem= valores[topo];
        topo--;
        return elem;
    }
}
