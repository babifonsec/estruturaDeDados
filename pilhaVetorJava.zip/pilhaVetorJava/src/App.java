public class App {
    public static void main(String[] args) throws Exception {
        int numero;
        
        if (args.length > 0) {
            numero = Integer.parseInt(args[0]);
        } else {
            numero = 10;
            System.out.println("nenhum argumento fornecido. usando valor padrao: 10");
        }
        
        Pilha p1 = new Pilha();
        int resto;

        //converter um decimal para binario, armazenando os restos
        while (numero != 0) {
            resto = numero % 2;
            p1.empilha(resto);
            numero = numero / 2;
        }

        while (!p1.vazio()) {
            resto = p1.desempilha();
            System.out.print(resto);
        }
        System.out.println();
    }
}